package com.remtv.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Pre-rendered, anti-aliased icon bitmaps (assets/icons/NAME_SIZE.png). The nearest larger size
 * is picked and scaled down by less than 2x, which keeps small icons crisp.
 */
final class Icons {
    private static final int[] SIZES = {32, 48, 64, 96, 128, 192};
    private static final Map<String, Bitmap> CACHE = new HashMap<>();

    private Icons() {
    }

    /** Returns the icon at exactly px x px, or null when the asset is missing. */
    static synchronized Bitmap get(Context c, String name, int px) {
        String key = name + "@" + px;
        Bitmap cached = CACHE.get(key);
        if (cached != null && !cached.isRecycled()) return cached;
        int pick = SIZES[SIZES.length - 1];
        for (int s : SIZES) {
            if (s >= px) {
                pick = s;
                break;
            }
        }
        try (InputStream in = c.getAssets().open("icons/" + name + "_" + pick + ".png")) {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b == null) return null;
            if (b.getWidth() != px) b = Bitmap.createScaledBitmap(b, px, px, true);
            CACHE.put(key, b);
            return b;
        } catch (Exception e) {
            return null;
        }
    }
}
