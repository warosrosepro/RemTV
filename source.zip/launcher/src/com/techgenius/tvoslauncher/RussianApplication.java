package ru.pro100tehnika.tvlauncher;
public class RussianApplication extends android.app.Application {
    @Override public void onCreate() {
        super.onCreate();
        Russian.init(this);
    }
}
