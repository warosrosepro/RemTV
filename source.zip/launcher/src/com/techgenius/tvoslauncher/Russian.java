package com.remtv.launcher;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.*;
import java.util.regex.*;

/** Russian display localization. Preference keys and data protocols stay unchanged. */
public final class Russian {
    private static final Map<String,String> WORDS = new HashMap<>();
    private static Pattern pattern;
    public static synchronized void init(Context context) {
        if (!WORDS.isEmpty()) return;
        try (InputStream in = context.getAssets().open("ru_complete.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192]; int n;
            while ((n=in.read(bytes))!=-1) out.write(bytes,0,n);
            JSONObject json = new JSONObject(out.toString("UTF-8"));
            Iterator<String> keys=json.keys();
            while(keys.hasNext()) {String key=keys.next();WORDS.put(key,json.getString(key));}
            List<String> sorted=new ArrayList<>(WORDS.keySet());
            Collections.sort(sorted,(a,b)->Integer.compare(b.length(),a.length()));
            StringBuilder regex=new StringBuilder("(?<![A-Za-z])(?:");
            for(String key:sorted) {if(regex.length()>22)regex.append('|');regex.append(Pattern.quote(key));}
            regex.append(")(?![A-Za-z])");
            pattern=Pattern.compile(regex.toString());
        } catch(Exception e) {android.util.Log.e("Russian", "Dictionary load failed",e);}
    }
    public static String text(String value) {
        if(value==null)return null;
        String direct=WORDS.get(value);if(direct!=null)return direct;
        if(pattern==null)return value;
        Matcher m=pattern.matcher(value);StringBuffer result=new StringBuffer();
        while(m.find())m.appendReplacement(result,Matcher.quoteReplacement(WORDS.get(m.group())));
        m.appendTail(result);return result.toString();
    }
    public static CharSequence text(CharSequence value) {
        if(value==null)return null;
        String translated=text(value.toString());
        return translated.equals(value.toString())?value:translated;
    }
    public static int text(int resource) {return resource;}
    public static char[] text(char[] value) {return value;}
}
