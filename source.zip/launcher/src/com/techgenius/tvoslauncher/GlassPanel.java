package ru.pro100tehnika.tvlauncher;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * A transparent "liquid glass" panel: a light tint that lets the blurred wallpaper show through, a soft
 * gloss near the top, and a thin rim that is brightest at the top-left and fades smoothly along the diagonal.
 */
final class GlassPanel extends Drawable {
    private final float radius, rimW;
    private final int tint;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final RectF inner = new RectF();
    private float rr, ri;

    /** @param tint colour (with alpha) laid over the wallpaper, @param rimW rim width in pixels */
    GlassPanel(float radius, int tint, float rimW) {
        this.radius = radius;
        this.tint = tint;
        this.rimW = Math.max(1f, rimW);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(tint);
        gloss.setStyle(Paint.Style.FILL);
        gloss.setDither(true);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(this.rimW);
        rim.setDither(true);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(Math.max(1f, this.rimW * 0.8f));
        edge.setDither(true);
    }

    private static int[] smooth(float peak, float tail) {
        int n = 13;
        int[] col = new int[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) (n - 1);
            double f = 0.5 * (1.0 + Math.cos(2.0 * Math.PI * t));
            double v = 0.18 + 0.82 * f;
            if (t > 0.5) v = 0.18 + (v - 0.18) * tail;
            col[i] = Color.argb((int) Math.round(255.0 * Math.min(1.0, peak * v)), 255, 255, 255);
        }
        return col;
    }

    private static float[] positions() {
        float[] p = new float[13];
        for (int i = 0; i < p.length; i++) p[i] = i / 12f;
        return p;
    }

    @Override
    protected void onBoundsChange(Rect b) {
        box.set(b);
        rr = Math.min(radius, Math.min(box.width(), box.height()) / 2f);
        rim.setShader(new LinearGradient(box.left, box.top, box.right, box.bottom,
                smooth(0.62f, 0.8f), positions(), Shader.TileMode.CLAMP));
        float in = rimW + Math.max(1f, rimW * 0.8f);
        inner.set(box.left + in, box.top + in, box.right - in, box.bottom - in);
        ri = Math.max(0f, rr - in);
        edge.setShader(new LinearGradient(box.left, box.top, box.right, box.bottom,
                smooth(0.12f, 0.8f), positions(), Shader.TileMode.CLAMP));
        gloss.setShader(new LinearGradient(0, box.top, 0, box.top + box.height() * 0.5f,
                new int[]{0x1CFFFFFF, 0x0EFFFFFF, 0x04FFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        if (box.isEmpty()) return;
        c.drawRoundRect(box, rr, rr, fill);
        c.drawRoundRect(box, rr, rr, gloss);
        float h = rimW / 2f;
        c.drawRoundRect(box.left + h, box.top + h, box.right - h, box.bottom - h,
                Math.max(0f, rr - h), Math.max(0f, rr - h), rim);
        c.drawRoundRect(inner, ri, ri, edge);
    }

    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
