package ru.pro100tehnika.tvlauncher;
import android.content.*;
import org.json.JSONObject;
import ru.pro100tehnika.tvlauncher.present.BootReceiver;
/** Explicit shell-only setup endpoint; DUMP permission is checked by Android. */
public class ConfigureReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        if (intent.hasExtra("boot")) BootReceiver.setLaunchOnBootEnabled(c,intent.getBooleanExtra("boot",true));
        if (intent.hasExtra("home_fix")) ButtonMapper.setHomeFixEnabled(c,intent.getBooleanExtra("home_fix",true));
        if (intent.hasExtra("lang")) I18n.setLang(c,intent.getStringExtra("lang"));
        if (intent.hasExtra("setup")) {
            c.getSharedPreferences("setup",Context.MODE_PRIVATE).edit()
                .putBoolean("setup_done",intent.getBooleanExtra("setup",true)).putInt("cur_step",0).apply();
            Profiles.homePrefs(c).edit().putBoolean("asked_default_home",true).apply();
        }
        try {
            JSONObject status=new JSONObject();
            status.put("boot",BootReceiver.isLaunchOnBootEnabled(c));
            status.put("home_fix",ButtonMapper.isHomeFixEnabled(c));
            status.put("lang",I18n.getLang(c));
            status.put("setup",c.getSharedPreferences("setup",Context.MODE_PRIVATE).getBoolean("setup_done",false));
            setResultData(status.toString());
        } catch(Exception e) {setResultCode(1);setResultData("Configuration failed");}
    }
}
