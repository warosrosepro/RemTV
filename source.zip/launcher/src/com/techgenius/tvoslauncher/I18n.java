package com.remtv.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Localization for RemTV: English (en) and Russian (ru).
 * Russian text comes from assets/ru_complete.json through {@link Russian}.
 */
public final class I18n {
    public static final String LANG_EN = "en";
    public static final String LANG_RU = "ru";

    public static final String[][] LANGUAGES = {
        {LANG_EN, "English", "Use RemTV in English"},
        {LANG_RU, "Русский", "Использовать RemTV на русском"}
    };

    private static String cachedLang;

    private I18n() { }

    private static boolean supported(String code) {
        return LANG_EN.equals(code) || LANG_RU.equals(code);
    }

    public static String detectSystemLang(Context c) {
        String raw = null;
        try {
            if (c != null && c.getResources() != null && c.getResources().getConfiguration() != null) {
                android.os.LocaleList locales = c.getResources().getConfiguration().getLocales();
                if (locales != null && !locales.isEmpty()) {
                    raw = locales.get(0).getLanguage();
                }
            }
        } catch (Throwable ignored) {
        }
        if (raw == null || raw.isEmpty()) {
            raw = Locale.getDefault().getLanguage();
        }
        if (raw == null || raw.isEmpty()) {
            return LANG_EN;
        }
        String code = raw.trim().toLowerCase(Locale.US);
        int sep = Math.max(code.indexOf('-'), code.indexOf('_'));
        if (sep > 0) {
            code = code.substring(0, sep);
        }
        return supported(code) ? code : LANG_EN;
    }

    public static void resetCache() {
        cachedLang = null;
    }

    public static String getLang(Context c) {
        if (cachedLang != null) return cachedLang;
        SharedPreferences p = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
        String saved = p.getString("lang", null);
        if (saved == null || !supported(saved)) {   // also moves anyone who had a removed language to Russian
            saved = LANG_RU;
            p.edit().putString("lang", saved).apply();
            if (!p.contains("clock_24h")) {
                Scenes.setClock24h(c, isDefault24hForLang(saved));
            }
        }
        cachedLang = saved;
        return cachedLang;
    }

    public static boolean isDefault24hForLang(String lang) {
        return !LANG_EN.equals(lang);
    }

    public static void setLang(Context c, String lang) {
        String valid = supported(lang) ? lang : LANG_EN;
        cachedLang = valid;
        c.getSharedPreferences("settings", Context.MODE_PRIVATE)
                .edit().putString("lang", valid).apply();
        Scenes.setClock24h(c, isDefault24hForLang(valid));
    }

    /** Turkish was removed; kept so older call sites keep compiling. Always false. */
    public static boolean isTr(Context c) {
        return false;
    }

    public static Locale locale(Context c) {
        return LANG_RU.equals(getLang(c)) ? Locale.forLanguageTag("ru-RU") : Locale.US;
    }

    /** Returns the English text, or its Russian translation when Russian is active. The second argument is unused. */
    public static String s(Context c, String en, String tr) {
        if (en == null) return "";
        return LANG_RU.equals(getLang(c)) ? Russian.text(en) : en;
    }

    /** Translates a key for the active language. */
    public static String t(Context c, String enKey) {
        if (enKey == null) return "";
        return LANG_RU.equals(getLang(c)) ? Russian.text(enKey) : enKey;
    }

    /** Formats the date line above the scene clock according to the active language. */
    public static String formatSceneDate(Context c, Date date) {
        if (LANG_RU.equals(getLang(c))) {
            return new SimpleDateFormat("EEEE d MMMM", locale(c)).format(date);
        }
        return new SimpleDateFormat("EEEE d MMMM", Locale.UK).format(date);
    }

    /** Translates default profile names ("Person 1", "Default", "Kids") while preserving custom names. */
    public static String profileName(Context c, String name) {
        if (name == null) return "";
        if (name.equals("Varsayılan")) return "Default";
        if (name.startsWith("Kişi ")) return "Person " + name.substring("Kişi ".length());
        if (name.startsWith("Profil ")) return "Profile " + name.substring("Profil ".length());
        return name;
    }
}
