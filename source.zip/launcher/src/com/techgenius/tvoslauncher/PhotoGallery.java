package com.remtv.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Liquid-glass photo gallery shown over the settings: a grid of previews where several photos can be
 * ticked (the number on a tick is the order in which they will appear).
 *  - "add" mode: every picture in the TV's Pictures folder; ticked ones are copied into the library.
 *  - "library" mode: all photos already added; ticked ones are the ones shown on the Home screen.
 */
final class PhotoGallery {
    private PhotoGallery() {
    }

    static void showAdd(Activity a, Runnable onChanged) {
        open(a, true, onChanged);
    }

    static void showLibrary(Activity a, Runnable onChanged) {
        open(a, false, onChanged);
    }

    private static String tx(Activity a, String en, String tr) {
        return com.remtv.launcher.Russian.text(I18n.s(a, en, tr));
    }

    private static void toast(Activity a, String en, String tr) {
        Toast.makeText(a, tx(a, en, tr), Toast.LENGTH_LONG).show();
    }

    private static void open(Activity a, boolean addMode, Runnable onChanged) {
        if (a == null || a.isFinishing()) return;
        if (addMode && !CustomMedia.hasStorageAccess(a)) {
            CustomMedia.ensureStoragePermissions(a);
            toast(a, "Allow access to files. The gallery opens by itself afterwards.",
                    "Dosyalara eri\u015fime izin verin. Galeri kendisi a\u00e7\u0131l\u0131r.");
            pollAccess(a, 0, onChanged);
            return;
        }
        if (!addMode) CustomMedia.removeLibraryDuplicates(a);   // clean up copies left by older versions
        List<File> files = addMode ? CustomMedia.scanPictures(a) : CustomMedia.libraryAll(a);
        if (files.isEmpty()) {
            if (addMode) {
                toast(a, "No photos found in the Pictures folder.", "Pictures klas\u00f6r\u00fcnde foto\u011fraf bulunamad\u0131.");
            } else {
                toast(a, "The library is empty. Add photos first.", "K\u00fct\u00fcphane bo\u015f. \u00d6nce foto\u011fraf ekleyin.");
            }
            return;
        }
        build(a, addMode, new ArrayList<>(files), onChanged);
    }

    /** Waits (up to ~30 s) for the one-time file access permission, then opens the gallery. */
    private static void pollAccess(Activity a, int tries, Runnable onChanged) {
        if (a.isFinishing() || tries > 40) return;
        a.getWindow().getDecorView().postDelayed(() -> {
            if (CustomMedia.hasStorageAccess(a)) {
                open(a, true, onChanged);
            } else {
                pollAccess(a, tries + 1, onChanged);
            }
        }, 800);
    }

    // ------------------------------------------------------------------ small UI helpers
    private static void setTextPx(TextView t, Activity a, float units) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, Ui.px(a, units));
    }

    private static TextView pill(Activity a, String text) {
        final TextView b = new TextView(a);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Ui.font(a, "semibold"));
        setTextPx(b, a, 9.5f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(Ui.px(a, 16), Ui.px(a, 7), Ui.px(a, 16), Ui.px(a, 7));
        b.setFocusable(true);
        b.setClickable(true);
        final GradientDrawable idle = new GradientDrawable();
        idle.setCornerRadius(Ui.px(a, 20));
        idle.setColor(0x26FFFFFF);
        idle.setStroke(Math.max(1, Ui.px(a, 0.7f)), 0x59FFFFFF);
        final GradientDrawable focus = new GradientDrawable();
        focus.setCornerRadius(Ui.px(a, 20));
        focus.setColor(Color.WHITE);
        b.setBackground(idle);
        b.setOnFocusChangeListener((v, has) -> {
            b.setBackground(has ? focus : idle);
            b.setTextColor(has ? 0xFF111114 : Color.WHITE);
        });
        return b;
    }

    private static Bitmap decodeThumb(File f, int targetW, int targetH) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= targetW && o.outHeight / (sample * 2) >= targetH) {
                sample *= 2;
            }
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = sample;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), d);
        } catch (Throwable t) {
            return null;
        }
    }

    /** One preview tile: rounded picture, a thin white ring when ticked and a numbered tick badge. */
    private static final class Tile extends FrameLayout {
        final ImageView img;
        final View ring;
        final TextView badge;
        final GradientDrawable badgeOff = new GradientDrawable();
        final GradientDrawable badgeOn = new GradientDrawable();
        String path;

        Tile(Activity a) {
            super(a);
            final float r = Ui.px(a, 9);
            setBackgroundColor(0x33FFFFFF);
            setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r);
                }
            });
            setClipToOutline(true);
            img = new ImageView(a);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            addView(img, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            ring = new View(a);
            GradientDrawable rg = new GradientDrawable();
            rg.setCornerRadius(r);
            rg.setColor(Color.TRANSPARENT);
            rg.setStroke(Math.max(2, Ui.px(a, 1.6f)), Color.WHITE);
            ring.setBackground(rg);
            ring.setVisibility(View.GONE);
            addView(ring, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            badge = new TextView(a);
            badge.setGravity(Gravity.CENTER);
            badge.setTextColor(Color.WHITE);
            badge.setTypeface(Ui.font(a, "semibold"));
            setTextPx(badge, a, 8.5f);
            badgeOff.setShape(GradientDrawable.OVAL);
            badgeOff.setColor(0x66000000);
            badgeOff.setStroke(Math.max(1, Ui.px(a, 0.9f)), 0xCCFFFFFF);
            badgeOn.setShape(GradientDrawable.OVAL);
            badgeOn.setColor(0xFF2D7CFF);
            badgeOn.setStroke(Math.max(1, Ui.px(a, 0.9f)), Color.WHITE);
            int bs = Ui.px(a, 20);
            FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(bs, bs, Gravity.TOP | Gravity.END);
            blp.topMargin = Ui.px(a, 6);
            blp.rightMargin = Ui.px(a, 6);
            addView(badge, blp);
        }

        void setOrder(int position) {   // position in the tick order, or -1
            if (position >= 0) {
                badge.setBackground(badgeOn);
                badge.setText(String.valueOf(position + 1));
                ring.setVisibility(View.VISIBLE);
            } else {
                badge.setBackground(badgeOff);
                badge.setText("");
                ring.setVisibility(View.GONE);
            }
        }

        void bind(final File f, final LruCache<String, Bitmap> cache, final ExecutorService pool, final int w, final int h) {
            final String p = f.getAbsolutePath();
            path = p;
            Bitmap cached = cache.get(p);
            if (cached != null) {
                img.setImageBitmap(cached);
                return;
            }
            img.setImageDrawable(null);
            try {
                pool.execute(() -> {
                    final Bitmap th = decodeThumb(f, w, h);
                    if (th == null) return;
                    cache.put(p, th);
                    post(() -> {
                        if (p.equals(path)) img.setImageBitmap(th);
                    });
                });
            } catch (Throwable ignored) {
            }
        }
    }

    // ------------------------------------------------------------------ the dialog
    private static void build(final Activity a, final boolean addMode, final List<File> files, final Runnable onChanged) {
        final int room = CustomMedia.LIBRARY_MAX - CustomMedia.libraryCount(a);
        final List<Integer> order = new ArrayList<>();   // ticked positions, in tick order
        if (!addMode) {
            for (File f : CustomMedia.libraryActive(a)) {
                int idx = files.indexOf(f);
                if (idx >= 0) order.add(idx);
            }
        }

        final Dialog dlg = new Dialog(a, android.R.style.Theme_Translucent_NoTitleBar);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x9904050A));
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    w.setBackgroundBlurRadius(30);
                } catch (Throwable ignored) {
                }
            }
        }

        int sw = a.getResources().getDisplayMetrics().widthPixels;
        int sh = a.getResources().getDisplayMetrics().heightPixels;
        int panelW = Math.round(sw * 0.86f);
        int panelH = Math.round(sh * 0.88f);
        int cols = panelW >= Ui.px(a, 760) ? 4 : 3;
        int pad = Ui.px(a, 18);
        int gap = Ui.px(a, 8);
        final int tileW = (panelW - 2 * pad - (cols - 1) * gap) / cols;
        final int tileH = Math.round(tileW * 9f / 16f);

        FrameLayout root = new FrameLayout(a);
        LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable pbg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xEB222A3E, 0xEE0B0E17});
        pbg.setCornerRadius(Ui.px(a, 24));
        pbg.setStroke(Math.max(1, Ui.px(a, 0.8f)), 0x66FFFFFF);
        panel.setBackground(pbg);
        root.addView(panel, new FrameLayout.LayoutParams(panelW, panelH, Gravity.CENTER));

        // ---- header
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(pad + Ui.px(a, 6), Ui.px(a, 16), pad + Ui.px(a, 6), Ui.px(a, 4));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(a);
        title.setText(addMode ? tx(a, "Add photos from the TV gallery", "TV galerisinden foto\u011fraf ekle")
                : tx(a, "Choose screensaver", "Ekran koruyucu se\u00e7"));
        title.setTextColor(Color.WHITE);
        title.setTypeface(Ui.font(a, "display"));
        setTextPx(title, a, 17);
        TextView sub = new TextView(a);
        sub.setText(addMode
                ? tx(a, "Pictures folder on this TV. Tick photos in the order you want them.", "Bu TV'deki Pictures klas\u00f6r\u00fc. Foto\u011fraflar\u0131 istedi\u011finiz s\u0131rayla i\u015faretleyin.")
                : tx(a, "Tick the photos for the Home screen. The numbers show their order.", "Ana ekran i\u00e7in foto\u011fraflar\u0131 i\u015faretleyin. Say\u0131lar s\u0131ray\u0131 g\u00f6sterir."));
        sub.setTextColor(0xB3FFFFFF);
        sub.setTypeface(Ui.font(a, "regular"));
        setTextPx(sub, a, 8.5f);
        titles.addView(title);
        titles.addView(sub);
        head.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView counter = new TextView(a);
        counter.setTextColor(Color.WHITE);
        counter.setTypeface(Ui.font(a, "semibold"));
        setTextPx(counter, a, 9);
        counter.setPadding(Ui.px(a, 14), Ui.px(a, 6), Ui.px(a, 14), Ui.px(a, 6));
        GradientDrawable cbg = new GradientDrawable();
        cbg.setCornerRadius(Ui.px(a, 18));
        cbg.setColor(0x26FFFFFF);
        cbg.setStroke(Math.max(1, Ui.px(a, 0.7f)), 0x4DFFFFFF);
        counter.setBackground(cbg);
        head.addView(counter);
        panel.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- grid of previews
        final GridView grid = new GridView(a);
        grid.setNumColumns(cols);
        grid.setHorizontalSpacing(gap);
        grid.setVerticalSpacing(gap);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setPadding(pad, Ui.px(a, 8), pad, Ui.px(a, 8));
        grid.setClipToPadding(false);
        grid.setVerticalScrollBarEnabled(false);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        GradientDrawable sel = new GradientDrawable();
        sel.setCornerRadius(Ui.px(a, 9));
        sel.setColor(0x22FFFFFF);
        sel.setStroke(Math.max(2, Ui.px(a, 2.2f)), 0xFFFFFFFF);
        grid.setSelector(sel);
        grid.setDrawSelectorOnTop(true);
        panel.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- footer buttons
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(pad, Ui.px(a, 6), pad, Ui.px(a, 14));
        panel.addView(foot, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final LruCache<String, Bitmap> cache = new LruCache<>(
                Math.max(8 * 1024 * 1024, (int) (Runtime.getRuntime().maxMemory() / 12)));
        final ExecutorService pool = Executors.newFixedThreadPool(3);
        dlg.setOnDismissListener(d -> pool.shutdownNow());

        final BaseAdapter adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return files.size();
            }

            @Override
            public Object getItem(int i) {
                return files.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View convert, ViewGroup parent) {
                Tile t = convert instanceof Tile ? (Tile) convert : new Tile(a);
                t.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, tileH));
                t.bind(files.get(i), cache, pool, tileW, tileH);
                t.setOrder(order.indexOf(i));
                return t;
            }
        };
        grid.setAdapter(adapter);

        final Runnable refreshCounter = () -> {
            String s = tx(a, "Selected: ", "Se\u00e7ilen: ") + order.size();
            if (addMode) s += "  \u00b7  " + tx(a, "Free: ", "Bo\u015f: ") + room;
            counter.setText(s);
        };
        refreshCounter.run();

        grid.setOnItemClickListener((parent, view, position, id) -> {
            int at = order.indexOf(position);
            if (at >= 0) {
                order.remove(at);
            } else {
                if (addMode && order.size() >= room) {
                    toast(a, "The library is full (60 photos).", "K\u00fct\u00fcphane dolu (60 foto\u011fraf).");
                    return;
                }
                order.add(position);
            }
            adapter.notifyDataSetChanged();
            refreshCounter.run();
        });

        TextView all = pill(a, tx(a, "Select all", "T\u00fcm\u00fcn\u00fc se\u00e7"));
        all.setOnClickListener(v -> {
            order.clear();
            int max = addMode ? Math.min(room, files.size()) : files.size();
            for (int i = 0; i < max; i++) order.add(i);
            adapter.notifyDataSetChanged();
            refreshCounter.run();
        });
        TextView none = pill(a, tx(a, "Clear selection", "Se\u00e7imi temizle"));
        none.setOnClickListener(v -> {
            order.clear();
            adapter.notifyDataSetChanged();
            refreshCounter.run();
        });
        TextView close = pill(a, tx(a, "Close", "Kapat"));
        close.setOnClickListener(v -> dlg.dismiss());

        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.leftMargin = Ui.px(a, 5);
        plp.rightMargin = Ui.px(a, 5);

        if (addMode) {
            TextView add = pill(a, tx(a, "Add selected", "Se\u00e7ilenleri ekle"));
            add.setOnClickListener(v -> {
                if (order.isEmpty()) {
                    toast(a, "Tick at least one photo.", "En az bir foto\u011fraf i\u015faretleyin.");
                    return;
                }
                List<File> picked = new ArrayList<>();
                for (int idx : order) picked.add(files.get(idx));
                dlg.dismiss();
                CustomMedia.importFiles(a, picked, onChanged);
            });
            foot.addView(add, plp);
            foot.addView(all, plp);
            foot.addView(none, plp);
        } else {
            TextView done = pill(a, tx(a, "Done", "Tamam"));
            done.setOnClickListener(v -> {
                List<File> chosen = new ArrayList<>();
                for (int idx : order) chosen.add(files.get(idx));
                CustomMedia.setLibraryActive(a, chosen);
                dlg.dismiss();
                if (onChanged != null) onChanged.run();
            });
            TextView del = pill(a, tx(a, "Delete selected", "Se\u00e7ilenleri sil"));
            del.setOnClickListener(v -> {
                if (order.isEmpty()) {
                    toast(a, "Tick the photos to delete.", "Silinecek foto\u011fraflar\u0131 i\u015faretleyin.");
                    return;
                }
                new AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle(tx(a, "Delete the selected photos from the library?", "Se\u00e7ili foto\u011fraflar k\u00fct\u00fcphaneden silinsin mi?"))
                        .setPositiveButton(tx(a, "Delete", "Sil"), (d, which) -> {
                            List<File> gone = new ArrayList<>();
                            for (int idx : order) gone.add(files.get(idx));
                            for (File f : gone) {
                                f.delete();
                                files.remove(f);
                            }
                            order.clear();
                            CustomMedia.useLibraryAsScene(a);
                            if (files.isEmpty()) {
                                dlg.dismiss();
                                if (onChanged != null) onChanged.run();
                                return;
                            }
                            adapter.notifyDataSetChanged();
                            refreshCounter.run();
                        })
                        .setNegativeButton(tx(a, "Cancel", "\u0130ptal"), null)
                        .show();
            });
            foot.addView(done, plp);
            foot.addView(all, plp);
            foot.addView(none, plp);
            foot.addView(del, plp);
        }
        foot.addView(close, plp);

        dlg.setContentView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        dlg.show();
        grid.requestFocus();
        grid.setSelection(0);
    }
}
